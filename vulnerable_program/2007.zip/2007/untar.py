import tarfile
import os 

TARGET_DIR_NAME = 'target'

with tarfile.open(f'{TARGET_DIR_NAME}/terry.tar') as tf:
    for m in tf.getmembers():
        print(f'member name is: {m.name}')

        # what the new tarfile.extractall() filter does before it writes 
        # every single file. we're NOT writing the files to demonstrate 
        # how the exploit works prior to proper use of features introduced 
        # in py 3.11.4
        # 
        # source can be here
        # https://github.com/python/cpython/blob/17f994174de9211b2baaff217eeb1033343230fc/Lib/tarfile.py#L754
        
        dest_path = os.path.realpath(f'{TARGET_DIR_NAME}')
        print(f'dest_path is: {dest_path}')

        target_path = os.path.realpath(os.path.join(dest_path, m.name))
        print(f'target_path is: {target_path}')

        is_tarslip = not os.path.commonpath([target_path, dest_path])
        print(f'is_tarslip? {is_tarslip}')
        print('-*-*-*-*-')


