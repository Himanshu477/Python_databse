# -*- coding: utf-8 -*-

__title__ = 'DHEater'
__version__ = '0.4.3'
__description__ = 'D(HE)ater is an attacking tool heating the CPU by enforcing DHE KEX in case of TLS and SSH'
__author__ = 'Szilárd Pfeiffer'
__maintainer__ = 'Szilárd Pfeiffer'
__maintainer_email__ = 'coroner@pfeifferszilard.hu'
__url__ = 'https://gitlab.com/dheatattack/dheater'
__license__ = 'Apache-2.0'
