#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sysconfig

def main():
    # Determine the script installation path based on the system configuration
    scripts = sysconfig.get_path('scripts')
    base = sysconfig.get_config_var('base')
    
    # Calculate the relative path of the scripts directory
    end = scripts.removeprefix(base)
    
    userbase = sysconfig.get_config_var('userbase')
    
    # Display the message instructing the user to check their PATH environment variable
    print(f"Check {userbase + end}/ is included in your PATH environment variable for system-wide execution.")
    
    # Ask the user if they want to add the directory to their PATH
    answer = input(f"Add the Python scripts directory to the PATH environment variable for system-wide execution?\n"
                   f"e.g. export PATH=$PATH:{userbase + end}/\ny/n: ").strip().lower()
    
    if answer in ["y", "yes"]:
        # Append the Python scripts directory to PATH in bash
        bashrc_path = os.path.expanduser("~/.bashrc")
        with open(bashrc_path, "a") as file_object:
            file_object.write(f"\nexport PATH=$PATH:{userbase + end}/\n")
        print(f"{userbase + end}/ added to PATH.")
        os.system("echo $PATH")
    elif answer in ["n", "no"]:
        print(f"If you need system-wide execution, add the Python scripts directory to the PATH environment variable manually: {userbase + end}/")
    else:
        print("Invalid input. Please respond with 'y' or 'n'.")

if __name__ == "__main__":
    main()
