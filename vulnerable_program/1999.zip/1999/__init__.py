"""
dns zone transfer test init

A python library of variables auto imported when calling dns-zone-transfer inside a python interpreter.
"""

__version__ = "1.0.1"
__author__ = "Rodney O C Melby"
__credits__ = "Bob Halley"
