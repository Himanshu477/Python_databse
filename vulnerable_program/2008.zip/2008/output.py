def tentative(string):
    print("\n\033[94m[?]\033[0m "+string)

def positive(string):
    print("\n\033[92m[+]\033[0m "+string)

def negative(string):
    print("\n\033[91m[-]\033[0m "+string)
